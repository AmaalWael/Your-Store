package Amazon;

public class Admin extends USER {
    public boolean add_admin(Admin admin){
        return true;
    }
    public boolean add_brand(String brand){
        return true;
    }
    public boolean add_store_owner(Store_owner storeOwner){
        return true;
    }
}
