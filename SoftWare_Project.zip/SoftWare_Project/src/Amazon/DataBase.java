package Amazon;

import javax.swing.table.DefaultTableModel;
import java.sql.*;
import java.util.Objects;
import java.util.Vector;

public class DataBase {
    private static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
    private static final String DB_URL = "jdbc:mysql://localhost:8889/YourStore";
    private static final String USER = "root";
    private static final String PASS = "root";
    private static Connection conn;
    private static Statement stmt;
    public DataBase() {
        conn = null;
        try{
            Class.forName("com.mysql.jdbc.Driver");
            System.out.println("Connecting to database...");
            conn = DriverManager.getConnection(DB_URL,USER,PASS);
        } catch(Exception e){
            e.printStackTrace();
        }
    }
    private boolean exec(String qry){
        try {
            stmt = conn.createStatement();
            int i = stmt.executeUpdate(qry);
            return i > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
    private ResultSet get_result(String qry){
        try {
            stmt = conn.createStatement();
            return stmt.executeQuery(qry);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
    public void close() {
        try {
            if (stmt != null)
                stmt.close();
        } catch (SQLException se2) {
            se2.printStackTrace();
        }
        try {
            if (conn != null)
                conn.close();
        } catch (SQLException se) {
            se.printStackTrace();
        }
    }
    public boolean save_user(USER user ,String type){
        String cid = String.valueOf(Add_cart(user.getCart()));
        String pid = String.valueOf(add_payment(user.getPayment()));
        String sql = "INSERT INTO `User` (`Uid`, `Name`, `Pass`, `BirthDate`, `Address`, `Email`, `Phone`, `type`, `Cartid`, `Payid`)VALUES( '"+user.getID()+"' , '"+user.getName()+"', '"+user.getPassword()+"', '"+user.getBirthDate()+"', '"+user.getAddress()+"', '"+user.getEmail()+"', '"+user.getNumber()+"',  '"+type+"' , "+cid+", "+pid+");";
        return exec(sql);
    }
    public int add_payment(Payment payment){
        String sql = "INSERT INTO `Payment` (`type`, `Amount`)\n" +
                "VALUES\n" +
                "\t( '"+payment.getType()+"', "+String.valueOf(payment.getAmount())+");";
        exec(sql);
        sql = "select max(`Payid`) from `Payment`";
        ResultSet rs = get_result(sql);
        try {
            rs.first();
            return rs.getInt(1);
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return -1;
    }
    public boolean search(String id, String pass){
        String sql = "select `Uid` , `Pass` from `User`";
        ResultSet rs = get_result(sql);
        try {
            assert rs != null;
            while (rs.next()){
                if (Objects.equals(rs.getString("Uid"), id) && Objects.equals(rs.getString("Pass"), pass))
                    return true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
    public ResultSet search(String key, char t){
        String qry;
        if (t == 'n'){
            qry = "Select p.`Productid` as 'Product ID', p.`Name` as 'Product Name'  , p.`price` , b.`Name` as 'Brand Name'\n" +
                    "from `Product` as p, `Brand` as b\n" +
                    "where b.`Bid` = p.`Brand_id`\n" +
                    "and (p.`Name` like '%"+key+"%' or b.`Name` like '%"+key+"%');";
        }
        else {
            qry = "Select p.`Productid` as 'Product ID', p.`Name` as 'Product Name'  , p.`price` , p.`Shows` as 'Number of views'  , b.`Name` as 'Brand Name'\n" +
                    "from `Product` as p, `Brand` as b\n" +
                    "where b.`Bid` = p.`Brand_id`\n" +
                    "and (p.`Name` like '%" + key + "%' or b.`Name` like '%" + key + "%');";
        }
        ResultSet rs = get_result(qry);
        try {
            assert rs != null;
            while (rs.next()){
                exec("update `Product` set `Shows` = `Shows` + 1 where `Productid` = "+rs.getString(1)+"");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return rs;
    }
    public int add_product(Product product){
        String sql_check = "SELECT `Name`, `Bid` from `Brand`;";
        boolean done = false;
        int bid = -1;
        try {
            ResultSet rs = get_result(sql_check);
            assert rs != null;
            while (rs.next()){
                if (rs.getString(1).equals(product.getBrand())){
                    done = true;
                    bid = rs.getInt(2);
                    break;
                }
            }
        }catch (SQLException e){
            e.printStackTrace();
        }
        if (done) {
            String sql = "INSERT INTO `Product` (`Name`, `Brand_id`, `price`)" +
                    "VALUES" +
                    "('"+product.getName()+"', "+String.valueOf(bid)+", "+String.valueOf(product.getPrice())+");";
            exec(sql);
            try {
                ResultSet resultSet = get_result("select max(`Productid`)from `Product`;");
                resultSet.first();
                bid = resultSet.getInt(0);
            }catch (SQLException e){
                e.printStackTrace();
            }
        }
        return bid;
    }
    public boolean add_store(Store store){
        Vector<Product> products = store.getProducts();
        Vector<String> brands = store.getBrands();
        String sql_check = "SELECT `Name` from `Store`;";
        boolean done = true;
        try {
            ResultSet rs = get_result(sql_check);
            assert rs != null;
            while (rs.next()){
                if (Objects.equals(rs.getString(0), store.getName())){
                    done = false;
                    break;
                }
            }
        }catch (SQLException e){
            e.printStackTrace();
        }
        if (done){
            String sql = "INSERT INTO `Store` (`Name`, `Owner`, `Address`) " +
                    "VALUES " +
                    "('"+store.getName()+"', '"+store.getOwner().getID()+"', '"+store.getAdd()+"');";
            exec(sql);
            String  sid = "1";
            try {
                sid = get_result("select max(`Sid`)from `Store`;").getString(0);
            } catch (SQLException e) {
                e.printStackTrace();
            }
            for (String brand : brands)
                exec("INSERT INTO `Store_brand` (`Sid`, `Bid`) " +
                        "VALUES " +
                        " (" + sid + ", (SELECT `Bid` from `Brand` where `Name` = '" + brand + "';) );");
            for (Product product : products)
                exec("INSERT INTO `Store_item` (`Sid`, `Pid`) " +
                        "VALUES " +
                        "(" + sid + ", " + String.valueOf(add_product(product)) + ");");
            return true;
        }
        else {
            return false;
        }
    }
    public boolean add_brand(String brand){
        String sql_check = "SELECT `Name`, `Bid` from `Brand`;";
        boolean done = true;
        try {
            ResultSet rs = get_result(sql_check);
            assert rs != null;
            while (rs.next()){
                if (Objects.equals(rs.getString(0), brand)){
                    done = false;
                    break;
                }
            }
        }catch (SQLException e){
            e.printStackTrace();
        }
        if (done){
            String sql = "INSERT INTO `Brand` (`Name`) " +
                    "VALUES" +
                    " ('"+brand+"');";
            exec(sql);
        }
        return done;
    }
    public String getName(String id){
        try {
            String sql = "SELECT `Name` FROM `User` where `Uid` = '"+id+"';";
            ResultSet rs = get_result(sql);
            assert rs != null;
            rs.first();
            return rs.getString(1);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return "";
    }
    public int Add_cart(Cart cart){
        String sql = "insert into `Cart` (`Uid`) values ('"+cart.getUser().getID()+"')";
        exec(sql);
        sql = "select max(`Cid`) from `Cart`";
        ResultSet rs = get_result(sql);
        try {
            rs.first();
            return rs.getInt(1);
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return -1;
    }
    public boolean add_to_cart(String uid, String pid){
        String sql = null;
        try {
            String cid;
            ResultSet resultSet = get_result("select `Cartid` from `User` where `Uid` = "+uid+"");
            resultSet.first();
            cid = resultSet.getString(1);
            sql = "INSERT INTO `CartItem` (`Pid`, `Cid`)\n" +
                    "VALUES\n" +
                    "\t("+pid+", "+cid+");\n";
            double total = get_cart(cid).getPrice() + get_product(pid).getPrice();
            exec("update `Cart` set `price` = "+String.valueOf(total)+" where `Cid` = "+cid+" ;");
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return exec(sql);
    }
    public boolean add_to_fav(String uid, String pid){
        String sql = null;
        sql = "INSERT INTO `FavItem` (`Pid`, `Uid`)\n" +
                    "VALUES\n" +
                    "\t("+pid+", "+uid+");\n";
        return exec(sql);
    }
    public ResultSet get_carts(String uid, char t){
        String sql;
        if (t == 'n'){
            sql = "select `Pid` as 'Product Id' , p.`Name` as 'Product Name' , (SELECT `Name` from `Brand` where `Bid` = `Brand_id`) as 'Brand', p.`Price`\n" +
                    "from  `Cart` as c, `CartItem` as ci, `Product` as p\n" +
                    "WHERE c.`Uid` = '"+uid+"'\n" +
                    "and  c.`Cid` = ci.`Cid`\n" +
                    "and p.`Productid` = ci.`Pid`;";
        }
        else {
            sql = "select `Pid` as 'Product Id' , p.`Name` as 'Product Name' , (SELECT `Name` from `Brand` where `Bid` = `Brand_id`) as 'Brand', p.`Price` , p.`Shows` as 'Number of views'\n" +
                    "from  `Cart` as c, `CartItem` as ci, `Product` as p\n" +
                    "WHERE c.`Uid` = '" + uid + "'\n" +
                    "and  c.`Cid` = ci.`Cid`\n" +
                    "and p.`Productid` = ci.`Pid`;";
        }
        return get_result(sql);
    }
    public ResultSet get_fav(String uid, char t){
        String sql;
        if (t == 'n'){
            sql = "select `Pid` as 'Product Id' , p.`Name` as 'Product Name' , (SELECT `Name` from `Brand` where `Bid` = `Brand_id`) as 'Brand', p.`Price`\n" +
                    "                from   `FavItem` as ci, `Product` as  p\n" +
                    "                WHERE ci.`Uid` = '1'\n" +
                    "                and p.`Productid` = ci.`Pid`;";
        }
        else {
            sql = "select `Pid` as 'Product Id' , p.`Name` as 'Product Name' , (SELECT `Name` from `Brand` where `Bid` = `Brand_id`) as 'Brand', p.`Price` , p.`Shows` as 'Number of views'\n" +
                    "                from   `FavItem` as ci, `Product` as  p\n" +
                    "                WHERE ci.`Uid` = '1'\n" +
                    "                and p.`Productid` = ci.`Pid`;";
        }
        return get_result(sql);
    }
    public USER get_user(String uid){
        USER user = new USER();
        ResultSet resultSet = get_result("select * from `User` where `Uid` = '"+uid+"';");
        try {
            resultSet.first();
            user.setID(uid);
            user.setPayment(get_payment(resultSet.getString("PayID")));
            user.setCart(get_cart(resultSet.getString("Cartid")));
            user.setType(resultSet.getString("type"));
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return user;
    }
    public Cart get_cart(String cid){
        String sql = "select * from `Cart` where `Cid` = "+cid+"";
        ResultSet resultSet = get_result(sql);
        Cart cart = new Cart(cid);
        try {
            resultSet.first();
            cart.setPrice(resultSet.getDouble(3));
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return cart;
    }
    public Payment get_payment(String pid){
        String sql = "select * from `Payment` where `Payid` = "+pid+"";
        ResultSet resultSet = get_result(sql);
        Payment pay = new Payment(pid);
        try {
            resultSet.first();
            pay.setAmount(resultSet.getFloat(3));
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return pay;
    }
    public Product get_product(String pid){
        String sql = "select * from `Product` where `Productid` = "+pid+"";
        ResultSet resultSet = get_result(sql);
        Product p = new Product(pid);
        try {
            resultSet.first();
            p.setPrice(resultSet.getFloat(4));
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return p;
    }
    public boolean buy(String uid){
        USER user = get_user(uid);
        String sql = "";
        if (user.getCart().getPrice() > user.getPayment().getAmount())
            return false;
        else{
            double new_balance = user.getPayment().getAmount() - user.getCart().getPrice() ;
            sql = "update `Payment` set `Amount` = "+String.valueOf(new_balance)+" where `Payid` = "+String.valueOf(user.getPayment().getId())+";";
            exec(sql);
            return true;
        }
    }
    public boolean make_admin(String uid){
        String sql = "update `User` set `type` = 'a' where `Uid` = '"+uid+"'";
        return exec(sql);
    }
    public boolean set_voucher(String uid, int value){
        USER user = get_user(uid);
        String pid = user.getPayment().getId();
        value += user.getPayment().getAmount();
        String sql = "update `Payment` set `Amount` = "+String.valueOf(value)+" where `Payid` = "+pid+" ;";
        return exec(sql);
    }
    public ResultSet getStores(){
        return get_result("select `Name` from `Store`;");
    }
    public String get_store_id(String name){
        String sql = "Select `Sid` from `Store` where `Name` = '"+name+"';";
        ResultSet resultSet = get_result(sql);
        String id = "-1";
        try {
            resultSet.first();
            id = resultSet.getString(1);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return id;
    }
    public boolean add_to_store(String pid, String sid){
        String sql = "INSERT INTO `Store_item` (`Sid`, `Pid`)\n" +
                "VALUES\n" +
                "\t("+sid+", "+pid+");\n";
        return exec(sql);
    }
    public boolean suggest(String pname, String bname){
        String sql = "INSERT INTO `Sug` ( `pname`, `bname`)\n" +
                "VALUES\n" +
                "\t( '"+pname+"', '"+bname+"');\n";
        return exec(sql);
    }
    public ResultSet get_suggested(){
        String sql = "select `bname` as 'Brand Name', `pname` as 'Product Name' from `Sug`;";
        ResultSet resultSet = get_result(sql);
        return resultSet;
    }
    private static DefaultTableModel buildTableModel(ResultSet rs) throws SQLException {

        ResultSetMetaData metaData = rs.getMetaData();

        // names of columns
        Vector<String> columnNames = new Vector<>();
        int columnCount = metaData.getColumnCount();
        for (int column = 1; column <= columnCount; column++) {
            columnNames.add(metaData.getColumnName(column));
        }

        // data of the table
        Vector<Vector<String>> data = new Vector<>();
        rs.beforeFirst();
        while (rs.next()) {
            Vector<String> vector = new Vector<>();
            for (int columnIndex = 1; columnIndex <= columnCount; columnIndex++)
                vector.addElement(rs.getString(columnIndex));
            data.addElement(vector);
        }

        return new DefaultTableModel(data, columnNames);

    }
    public ResultSet get_all_in_store(String s) {
        String sid = get_store_id(s);
        String sql = "Select p.`Productid` as 'Product ID', p.`Name` as 'Product Name'  , p.`price` , (SELECT `Name` from `Brand` where `Bid` = `Brand_id`) as 'Brand', p.`Shows` as 'Number of views'\n" +
                "from `Product` as p, `Store_item` as s\n" +
                "where s.`Sid` = "+sid+"\n" +
                "and p.`Productid` = s.`Pid`";
        return get_result(sql);
    }
    public void delete_cart_items(String cid){
        String sql;
        sql = "delete from `CartItem` where `Cid` = "+cid+"";
        exec(sql);
    }
}